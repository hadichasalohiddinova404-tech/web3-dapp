// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Game {
    address public owner;
    mapping(address => uint256) public scores;

    event ScoreUpdated(address player, uint256 score);

    constructor() {
        owner = msg.sender;
    }

    function updateScore(uint256 _score) public {
        scores[msg.sender] = _score;
        emit ScoreUpdated(msg.sender, _score);
    }

    function getScore(address _player) public view returns (uint256) {
        return scores[_player];
    }
}
